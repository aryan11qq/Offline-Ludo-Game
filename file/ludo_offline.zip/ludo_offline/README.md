# ludo_offline
Offline ludo game developed in android studio


Hello Guy(s),

Thanks for considering a look here, You can find a simple android ludo game developed in android studio. This is just sample project to illustrate canvas in android with threading for game development. 

This is 2D game developed for a simple stat of game development in android studio. Please go through code and you can understand yourself. If you still face any issues then do post issues and I will try to solve it.

Happy coding!
